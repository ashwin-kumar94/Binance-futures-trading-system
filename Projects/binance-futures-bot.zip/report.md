# Report: Binance Futures Testnet Trading Bot (CLI)

## Overview
This project is a CLI-based trading bot for Binance USDT-M Futures Testnet. It supports mandatory Market and Limit orders (BUY/SELL) and includes validation, structured logging, and resilient error handling. Optional strategies include TWAP, Grid, and a simulated OCO.

## Architecture
- `src/common.py`: Client factory for UMFutures (Testnet by default), argument validators, retry wrapper, and console pretty-print for order results.
- `src/logger_setup.py`: Centralized logging setup (rotating file handler to `bot.log`, plus console handler).
- `src/market_orders.py`: Market order placement using `client.new_order` with optional `reduceOnly` and `positionSide`.
- `src/limit_orders.py`: Limit order placement including `timeInForce`, `quantity`, and `price`.
- `src/advanced/oco.py`: Simulated OCO via `TAKE_PROFIT` and `STOP_MARKET` orders.
- `src/advanced/twap.py`: TWAP strategy that slices a total quantity over time.
- `src/advanced/grid.py`: Grid strategy generating a series of limit orders across a price range.
- `src/cli.py`: CLI wiring subcommands to order functions and validations.

## Error Handling & Retries
- Client-side errors (e.g., 429 rate limits, 408 timeouts) are retried with exponential backoff.
- Server-side errors (5XX) are retried.
- All errors are logged with clear context.

## Logging
- Structured logging with timestamps to `bot.log` via rotating file handler.
- Console printing focuses on key order fields for clarity.

## CLI Validation
- Symbol (alphanumeric), Side (BUY/SELL), and positive numeric validations.
- Helpful error messages printed and logged on invalid input.

## Example Runs
- Market:
  - `python src/cli.py market --symbol BTCUSDT --side BUY --quantity 0.001`
- Limit:
  - `python src/cli.py limit --symbol BTCUSDT --side SELL --quantity 0.001 --price 50000`
- TWAP:
  - `python src/cli.py twap --symbol BTCUSDT --side BUY --total-qty 0.01 --slices 5 --interval 2 --use-market`
- Grid:
  - `python src/cli.py grid --symbol BTCUSDT --side SELL --lower 48000 --upper 52000 --steps 4 --order-qty 0.001`
- Simulated OCO:
  - `python src/cli.py oco --symbol BTCUSDT --side SELL --quantity 0.001 --tp 52000 --sl 45000`

## Design Choices
- Minimal dependencies (`binance-connector`, `python-dotenv`, `reportlab`).
- Clear separation of concerns across modules.
- Reusable functions and structured payload composition.
- Optional strategies kept in `advanced/` folder.

## Screenshots and Logs
- Include terminal screenshots of successful order placements and relevant `bot.log` excerpts showing request/response and status.

## Next Steps
- Add user data stream for real-time events and automated OCO cancellation.
- Support additional order types (e.g., STOP_LIMIT, TRAILING_STOP_MARKET) as needed.